Windows Defense Quick Scripts - v2
=================================

Included scripts (double-click to run; right-click -> Run as administrator recommended):

1) Start_Defense_Tools.bat
   - Launches Process Explorer, TCPView, Autoruns, and Process Monitor (if present) from C:\Tools\Sysinternals.
   - Use this immediately after extracting the Sysinternals suite on the VM.

2) Quick_Baseline.bat
   - Saves a timestamped snapshot of system state to C:\GameLogs\<timestamp> (ipconfig, netstat, tasklist, services, scheduled tasks, Run keys, event logs).
   - Run after you create your secret admin and change competition passwords to capture a clean baseline.

3) Open_Firewall_GUI.bat
   - Opens the Windows Firewall control panel for quick access.

4) Open_Event_Viewer.bat
   - Opens Event Viewer for checking System and Security logs.

5) List_Users_Admins.bat
   - Generates a quick text report of local users and the Administrators group and opens it in Notepad.

6) Firewall_Reset.bat
   - Resets the Windows Firewall to default and re-enables it (use when the Red Team has disabled or modified firewall rules).

Notes:
- These scripts are informational and recovery focused; they do not perform destructive actions.
- Always run them with administrative privileges for full access.
- The scripts assume Sysinternals tools are at C:\Tools\Sysinternals. If you keep them elsewhere, edit Start_Defense_Tools.bat accordingly.
- You can upload this ZIP to your GitHub repo and download it inside the competition VM (no USB needed).

Good luck — run Start_Defense_Tools.bat first to launch your monitoring suite.
